import React from "react";
import "./Donateheader.css";


function Donateheader() {
  return (
    <div id="donateheaderbox">
        <div id="header">
            <p>기부하기</p>
            <button>뒤로가기</button>
        </div>
    </div>
  );
}

export default Donateheader;
